# Start Here — CodeAlpha Data Analytics Internship

This starter package contains two related tasks:
1. `CodeAlpha_EDA/` — Exploratory Data Analysis
2. `CodeAlpha_DataVisualization/` — Data Visualization

Both use `Shared_Dataset/sample_retail_sales.csv`, a simulated 2025 retail-sales practice dataset with 240 rows. It is explicitly synthetic, not real company data.

## Recommended order
1. Read each project's README.
2. Install Python and dependencies.
3. Run the EDA script, inspect its output, and then run the visualization script.
4. Read `PROJECT_REPORT.md` and update your video scripts with actual results.
5. Follow `LINKEDIN_VIDEO_SCRIPTS.md` to record separate screen-recordings.
6. Upload each project to its own GitHub repository.

The projects are prepared as a beginner-friendly starting point. Please run and understand the scripts yourself before submitting them. Confirm with your internship coordinator that a synthetic practice dataset is acceptable if they expect a dataset from a real public source.
