# CodeAlpha Data Analytics Internship — Project Report

## Project 1: Exploratory Data Analysis (EDA)
**Objective:** Understand the structure and quality of the data, summarize sales, and explore differences by product category, region, and month.

**Dataset:** `sample_retail_sales.csv`, a generated practice dataset of 240 simulated orders from 2025. It is not real business data.

**Tools:** Python, pandas, Matplotlib.

**Workflow:**
1. Load the CSV and convert the order date to a date type.
2. Inspect the first rows, dimensions, column types, missing values, duplicates, and numerical summary.
3. Remove exact duplicate rows and records missing essential fields.
4. Calculate total sales, average order value, category sales, regional sales, and monthly sales.
5. Save summary tables and an overview chart.

**Questions answered by the code:** What are total sales and average order value? Which categories and regions have the highest sales in this sample? How do sales change month by month? Are there data-quality issues?

**Results:** Run `eda_analysis.py` and copy the values printed by the script into your final presentation. Because this is a generated dataset, describe results as findings from a simulated practice dataset, not from a real company.

**Limitations:** The sample is small and simulated. It does not establish real customer behavior, profitability, causation, or future sales.

## Project 2: Data Visualization
**Objective:** Present the dataset through clear charts to make patterns easier to identify.

**Visuals created:**
- Monthly sales trend line chart.
- Total sales by product category bar chart.
- Sales by region bar chart.
- Distribution of sales per order histogram.

**Workflow:** Load and lightly clean the same practice dataset, aggregate sales into monthly/category/region summaries, create labeled charts, and export summary CSVs.

**Results:** Use the generated PNGs and actual printed category/region totals when recording your video. Explain what each axis represents and state the pattern visible in the chart. Avoid claiming a result that is not supported by the chart.

**Limitations:** The same synthetic-data limitation applies. Visualizations are useful for exploring the sample but should not be treated as evidence about a real business.

## How to reproduce
Each project folder contains a Python script and `requirements.txt`. Follow its README. Run both scripts locally before submitting, check that the outputs are generated, and include the actual charts/results in your GitHub repositories.

## Submission checklist
- [ ] Run both scripts on your laptop.
- [ ] Review all generated charts and console output.
- [ ] Update any spoken results to match your run.
- [ ] Create separate GitHub repositories named `CodeAlpha_EDA` and `CodeAlpha_DataVisualization`.
- [ ] Upload the relevant script, README, requirements, dataset, and generated output charts/tables.
- [ ] Record one video per task showing the code and outputs.
- [ ] Publish each video on LinkedIn and include the corresponding GitHub repository link; tag `@CodeAlpha` as requested in the internship PDF.
- [ ] Submit using the form provided in your internship WhatsApp group.
