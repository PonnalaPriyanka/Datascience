# CodeAlpha — Exploratory Data Analysis (EDA)

## Objective
Explore a retail-sales dataset, inspect data quality, summarize numerical columns, and investigate sales by category, region, and month.

## Dataset
`data/sample_retail_sales.csv` contains 240 **synthetic** practice orders created for this project. It is not real company data and does not contain real customer records.

## Tools
Python, pandas, Matplotlib.

## Run
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python eda_analysis.py`

## Outputs
The script creates an `outputs/` folder with category, region, and monthly summary CSVs plus `eda_overview.png`.

## Questions
- What is the overall sales total and average order value?
- How do sales differ by category and region?
- How does sales volume change month to month?
- Are there missing values or duplicate rows?

## Important
Before submitting, run the script yourself, inspect its output, and update the project report/video with the actual results it prints. Do not claim this generated practice data represents a real business.
