"""
CodeAlpha Data Analytics Internship — Task: Exploratory Data Analysis (EDA)
Dataset: ../Shared_Dataset/sample_retail_sales.csv
NOTE: This is a synthetic practice dataset created for this portfolio project,
not real company/customer data.
Run from this folder: python eda_analysis.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
LOCAL_DATA_PATH = ROOT / "data" / "sample_retail_sales.csv"
DATA_PATH = LOCAL_DATA_PATH if LOCAL_DATA_PATH.exists() else ROOT.parent / "Shared_Dataset" / "sample_retail_sales.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH)
df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")

print("=" * 65)
print("CODEALPHA | EXPLORATORY DATA ANALYSIS")
print("=" * 65)
print(f"Dataset shape: {df.shape[0]} rows x {df.shape[1]} columns")
print("\nFirst five rows:")
print(df.head().to_string(index=False))
print("\nColumn data types:")
print(df.dtypes)
print("\nMissing values per column:")
print(df.isna().sum())
print(f"\nDuplicate rows: {df.duplicated().sum()}")
print("\nNumerical summary:")
print(df[["Quantity", "Unit_Price_INR", "Discount_Rate", "Sales_INR"]].describe().round(2))

# Create a cleaned working copy: remove exact duplicates and rows missing essential fields.
before = len(df)
df = df.drop_duplicates()
df = df.dropna(subset=["Order_ID", "Order_Date", "Product", "Sales_INR"])
print(f"\nRows before cleaning: {before}; rows after cleaning: {len(df)}")

# Questions explored: What are total sales? Which categories/regions perform best?
total_sales = df["Sales_INR"].sum()
average_order = df["Sales_INR"].mean()
top_category = df.groupby("Category")["Sales_INR"].sum().sort_values(ascending=False)
top_region = df.groupby("Region")["Sales_INR"].sum().sort_values(ascending=False)
monthly_sales = df.set_index("Order_Date").resample("MS")["Sales_INR"].sum()

print(f"\nTotal sales (INR): ₹{total_sales:,.2f}")
print(f"Average order value (INR): ₹{average_order:,.2f}")
print("\nSales by category (INR):")
print(top_category.round(2).to_string())
print("\nSales by region (INR):")
print(top_region.round(2).to_string())
print("\nMonthly sales (INR):")
print(monthly_sales.round(2).to_string())

# Save key summary tables.
top_category.rename("Sales_INR").to_csv(OUTPUT_DIR / "sales_by_category.csv")
top_region.rename("Sales_INR").to_csv(OUTPUT_DIR / "sales_by_region.csv")
monthly_sales.rename("Sales_INR").to_csv(OUTPUT_DIR / "monthly_sales.csv")

# Visual checks for the EDA task.
fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
df["Sales_INR"].plot(kind="hist", bins=20, ax=axes[0], edgecolor="black")
axes[0].set_title("Distribution of Order Sales")
axes[0].set_xlabel("Sales (INR)")
axes[0].set_ylabel("Order count")
top_category.sort_values().plot(kind="barh", ax=axes[1])
axes[1].set_title("Total Sales by Category")
axes[1].set_xlabel("Sales (INR)")
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "eda_overview.png", dpi=160)
plt.close(fig)

print(f"\nOutputs saved in: {OUTPUT_DIR}")
print("Interpret results from this generated dataset only; do not describe it as real business data.")
