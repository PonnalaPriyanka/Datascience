"""
CodeAlpha Data Analytics Internship — Task: Data Visualization
Dataset: ../Shared_Dataset/sample_retail_sales.csv
NOTE: This is a synthetic practice dataset, not real company/customer data.
Run from this folder: python create_visualizations.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
LOCAL_DATA_PATH = ROOT / "data" / "sample_retail_sales.csv"
DATA_PATH = LOCAL_DATA_PATH if LOCAL_DATA_PATH.exists() else ROOT.parent / "Shared_Dataset" / "sample_retail_sales.csv"
OUTPUT_DIR = ROOT / "charts"
OUTPUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH, parse_dates=["Order_Date"])
df = df.drop_duplicates().dropna(subset=["Order_Date", "Sales_INR"])
df["Month"] = df["Order_Date"].dt.to_period("M").astype(str)

# Chart 1: monthly sales trend
monthly = df.groupby("Month", as_index=False)["Sales_INR"].sum()
fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(monthly["Month"], monthly["Sales_INR"], marker="o")
ax.set_title("Monthly Sales Trend — 2025")
ax.set_xlabel("Month")
ax.set_ylabel("Sales (INR)")
ax.tick_params(axis="x", rotation=45)
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "01_monthly_sales_trend.png", dpi=180)
plt.close(fig)

# Chart 2: category sales comparison
category = df.groupby("Category")["Sales_INR"].sum().sort_values()
fig, ax = plt.subplots(figsize=(9, 5))
category.plot(kind="barh", ax=ax)
ax.set_title("Total Sales by Product Category")
ax.set_xlabel("Sales (INR)")
ax.set_ylabel("Category")
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "02_sales_by_category.png", dpi=180)
plt.close(fig)

# Chart 3: regional sales
region = df.groupby("Region")["Sales_INR"].sum().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(7, 5))
region.plot(kind="bar", ax=ax)
ax.set_title("Sales by Region")
ax.set_xlabel("Region")
ax.set_ylabel("Sales (INR)")
ax.tick_params(axis="x", rotation=0)
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "03_sales_by_region.png", dpi=180)
plt.close(fig)

# Chart 4: sales distribution
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(df["Sales_INR"], bins=20, edgecolor="black")
ax.set_title("Distribution of Order Sales")
ax.set_xlabel("Sales per order (INR)")
ax.set_ylabel("Number of orders")
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "04_order_sales_distribution.png", dpi=180)
plt.close(fig)

# Export tables to make charts auditable/reusable.
monthly.to_csv(OUTPUT_DIR / "monthly_sales.csv", index=False)
category.rename("Sales_INR").to_csv(OUTPUT_DIR / "category_sales.csv")
region.rename("Sales_INR").to_csv(OUTPUT_DIR / "region_sales.csv")

print("Four charts and summary CSVs created in:", OUTPUT_DIR)
print("Dataset is synthetic. Report patterns as findings from a practice dataset only.")
print("\nSales by category:\n", category.sort_values(ascending=False).round(2).to_string())
print("\nSales by region:\n", region.round(2).to_string())
