# CodeAlpha — Data Visualization

## Objective
Turn retail-sales data into charts that make monthly trends, category comparisons, regional differences, and order-level distribution easier to understand.

## Dataset
`data/sample_retail_sales.csv` contains 240 **synthetic** practice orders created for this project. It is not real company data.

## Tools
Python, pandas, Matplotlib.

## Run
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python create_visualizations.py`

## Outputs
The script creates a `charts/` folder with four PNG charts and reusable summary CSVs.

## Interpretation
Use the printed category and region totals and the generated charts to describe the largest categories/regions and the monthly pattern. Mention only patterns visible in your actual outputs.
