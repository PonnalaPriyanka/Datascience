# Shared practice dataset

`sample_retail_sales.csv` contains 240 simulated retail orders dated in 2025. The values are randomly generated for learning and demonstration. They are not actual sales, customer, or company records. The dataset is shared between the EDA and Data Visualization tasks so both projects can be compared consistently.
